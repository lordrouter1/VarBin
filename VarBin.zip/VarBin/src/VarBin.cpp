#include "../include/VarBin.h"

/// CONSTRUTOR QUE RECEBE UMA STRING COMO PARAMETRO:
VarBin::VarBin(string input)
{
  for(unsigned i = 0; i < input.size(); i++)
  {
    if((int) input[i] > 255) return;
  }

	if(VectorBin.size() != 0)
	  VectorBin.clear();

	for(unsigned i = 0; i < input.size(); i++)
	{
	  VectorBin.push_back(conversor((int)input[i]));
  }
  return;
}

/// CONSTRUTOR QUE RECEBE UM CHAR COMO PARAMETRO:
VarBin::VarBin(char input)
{
  if((int) input > 255) return;

  if(VectorBin.size() != 0)
    VectorBin.clear();

	VectorBin.push_back(conversor((int)input));

	return;
}

/// CONSTRUTOR QUE RECEBE UM INT COMO PARAMETRO:
VarBin::VarBin(int input)
{
  if(input > 255) return;

  if(VectorBin.size() != 0)
    VectorBin.clear();

  VectorBin.push_back(conversor(input));

  return;
}

/// CONSTRUTOR QUE NÃO RECEBE PARAMETRO:
VarBin::VarBin()
{
}

/// OPERADOR DE ENTRADA QUE RECEPE UMA STRING COMO PARAMETRO:
void VarBin::operator << (string input)
{
  for(unsigned i = 0; i < input.size(); i++)
  {
    if((int) input[i] > 255) return;
  }

	if(VectorBin.size() != 0)
	  VectorBin.clear();

	for(unsigned i = 0; i < input.size(); i++)
	{
	  VectorBin.push_back(conversor((int)input[i]));
  }
  return;
}

/// OPERADOR DE ENTRADA QUE RECEBE UM CHAR COMO PARAMETRO:
void VarBin::operator << (char input)
{
  if((int) input > 255) return;

  if(VectorBin.size() != 0)
    VectorBin.clear();

    VectorBin.push_back(conversor((int)input));

  return;
}

///  OPERADOR DE ENTRADA QUE RECEBE UM INT COMO PARAMETRO:
void VarBin::operator<<(int input)
{
  if(input > 255) return;

  if(VectorBin.size() != 0)
    VectorBin.clear();

    VectorBin.push_back(conversor(input));
}

/// FUNÇÃO QUE CONVERTE UM VALOR INTEIRO EM _VARBIN_BYTE_STRUCT_:
_VARBIN_BYTE_STRUCT_ VarBin::conversor(int var)
{
  _VARBIN_CB_ conv;
  _VARBIN_BYTE_STRUCT_ retorna;

  conv.inteiro = var;

  retorna.bitVector[0] = conv.bite.bit8;
  retorna.bitVector[1] = conv.bite.bit7;
  retorna.bitVector[2] = conv.bite.bit6;
  retorna.bitVector[3] = conv.bite.bit5;
  retorna.bitVector[4] = conv.bite.bit4;
  retorna.bitVector[5] = conv.bite.bit3;
  retorna.bitVector[6] = conv.bite.bit2;
  retorna.bitVector[7] = conv.bite.bit1;

  return retorna;
}

/// FUNÇÃO QUE CONVERTE UMA _VARBIN_BYTE_STRUCT_ EM UM INTEIRO:
int VarBin::conversor(_VARBIN_BYTE_STRUCT_ var)
{
  _VARBIN_CB_ conv;
  int retorna;

  conv.bite.bit8 = var.bitVector[0];
  conv.bite.bit7 = var.bitVector[1];
  conv.bite.bit6 = var.bitVector[2];
  conv.bite.bit5 = var.bitVector[3];
  conv.bite.bit4 = var.bitVector[4];
  conv.bite.bit3 = var.bitVector[5];
  conv.bite.bit2 = var.bitVector[6];
  conv.bite.bit1 = var.bitVector[7];

  retorna = conv.inteiro;

  return retorna;
}

/// RETORNA STRING DOS BYTES (CASO SEJA UM VETOR DE BYTES RETORNA BYTE SEGUIDO DE BYTE SEM ESPAÇO):
string VarBin::toString()
{
  string bufferReturn = "";

  for(unsigned i = 0; i < VectorBin.size(); i++)
  {
    for(int j = 0; j < _VARBIN_BYTE_SIZE_; j++)
    {
      if(VectorBin[i].bitVector[j])
        bufferReturn += "1";
      else
        bufferReturn += "0";
    }
  }
  return bufferReturn;
}

/// RETORNA STRING DOS BYTES (CASO SEJA UM VETOR DE BYTE RETORNA BYTES COM ESPAÇAMENTO DEFINIDO POR INTEIRO EM REFERENCIA):
string VarBin::toString(int space)
{
  string bufferReturn = "";
  int spaceCont = 0;

  if(space == 0) return "Espaço Invalido!";
  if(space % 2 == 1) return "Apenas Valores Pares";

  for(unsigned i = 0; i < VectorBin.size(); i++)
  {
    for(int j = 0; j < _VARBIN_BYTE_SIZE_; j++)
    {
      if(spaceCont == space)
      {
        bufferReturn += " ";
        spaceCont = 1;
      }
      else
        spaceCont++;

      if(VectorBin[i].bitVector[j])
        bufferReturn += "1";
      else
        bufferReturn += "0";
    }
  }
  return bufferReturn;
}
