#ifndef VARBIN_H
#define VARBIN_H

#include "VarBinHeader.h"

class VarBin
{
	public:
	  //construtores:
		VarBin(string input);
		VarBin(char input);
		VarBin(int input);
		VarBin();

		//funções:
		string toString();
		string toString(int space);

		//operadores:
		void operator << (string input);
		void operator << (char input);
		void operator << (int input);



	private:
	  //variavel principal com vetor de bytes:
    vector<_VARBIN_BYTE_STRUCT_> VectorBin;

    // funções para converção de valores:
    _VARBIN_BYTE_STRUCT_ conversor(int var);
    int conversor(_VARBIN_BYTE_STRUCT_ var);
};

#endif // VARBIN_H
