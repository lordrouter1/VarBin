#ifndef VARBIN_H_INCLUDED
#define VARBIN_H_INCLUDED

#include "VarBin/src/VarBin.cpp"

#endif //VARBIN_H_INCLUDED
